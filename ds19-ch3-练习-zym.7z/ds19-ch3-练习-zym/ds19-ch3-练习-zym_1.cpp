#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
	int i,j,n,l;
	char s[150],p[150];
	cout<<"������һ���ַ�����"; 
	gets(s)!=NULL;
	n=strlen(s);
	j=0;                                      //��ʾ����
	l=1;
	for(i=0; i<n; i++) {
		if(s[i]=='{'||s[i]=='('||s[i]=='[') {
			p[j++]=s[i];
		}
		if(s[i]==')') {
			if(j==0) {
				l=0;
				break;
			}
			if(j>0&&p[j-1]=='(') {            //����һ��Ԫ�رȽ�
				j=j-1;
			} else if(j>0&&p[j-1]!='(') {
				l=0;
				break;
			}
		}
		if(s[i]==']') {
			if(j==0) {
				l=0;
				break;
			}
			if(j>0&&p[j-1]=='[') {
				j=j-1;
			} else if(j>0&&p[j-1]!='[') {
				l=0;
				break;
			}
		}
		if(s[i]=='}') {
			if(j==0) {
				l=0;
				break;
			}
			if(j>0&&p[j-1]=='{') {
				j=j-1;
			} else if(j>0&&p[j-1]!='{') {
				l=0;
				break;
			}
		}
	}
	if(l==0||j>0)
		printf("no\n");
	else if(j==0)
		printf("yes\n");

	return 0;
}
//��Դ��CSDN
//ԭ�ģ�https://blog.csdn.net/jert159/article/details/38499435
