#include<iostream>
using namespace std;
int main() {
	int n,num[1005],x=0,y=0,a[1005],b[1005];
	cin>>n;
	for(int i=0; i<n; i++) {
		cin>>num[i];
		if(num[i]%2==0) {//ż 
			b[y]=num[i];
			y++;
		}
		if(num[i]%2!=0) {//�� 
			a[x]=num[i];
			x++;
		}
	}
	if(x>=0) x=x-1;
	if(y>=0) y=y-1;
	int lenA=x,lenB=y;
	int k = 0;
	while(y>=0||x>=0) {
		int t=x;
		if(k) {
			cout<<" ";
			k=0;
		}
		if(x>=0) {
			cout<<a[lenA-x];
			x--;
			if(x>=0) {
				cout<<" "<<a[lenA-x];
				x--;
			}
		}
		if(t>=0&&y>=0) {
			cout<<" ";
		}
		if(y>=0) {
			cout<<b[lenB-y];
			y--;
		}
		if(x>=0||y>=0)
			k=1;
	}
	return 0;
}
